package com.example.pam_lab2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

import java.util.ArrayList;

public class UpdateBtnActivity extends AppCompatActivity {
    ArrayList<String> titleSelected = new ArrayList<>();
    ArrayList<String> timeSelected = new ArrayList<>();
    ArrayList<String> titleEvents = new ArrayList<>();
    ArrayList<String> descriptionEvents = new ArrayList<>();
    ArrayList<String> timeEvents = new ArrayList<>();
    ArrayList<String> dateEvents = new ArrayList<>();
    ArrayList<Integer> selected = new ArrayList<>();
    ListView listRemove;
    Button btnCancelRm, btnConfirmRm;
    boolean existItem = false;
    String uptitle,updescription,uptime,update;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_btn);
        getSupportActionBar().hide();

        listRemove = findViewById(R.id.updateList);
        btnCancelRm = findViewById(R.id.btnSelect);
        btnConfirmRm = findViewById(R.id.btnConfirmUp);

        titleSelected = getIntent().getStringArrayListExtra("titleSelected");
        timeSelected = getIntent().getStringArrayListExtra("timeSelected");

        titleEvents = getIntent().getStringArrayListExtra("eventsTitle");
        descriptionEvents = getIntent().getStringArrayListExtra("eventsDescription");
        timeEvents = getIntent().getStringArrayListExtra("eventsTime");
        dateEvents = getIntent().getStringArrayListExtra("eventsDate");

        String dateSelected = getIntent().getStringExtra("dateSelected");
        showEvents();
        listRemove.setChoiceMode(ListView.CHOICE_MODE_SINGLE);

        btnCancelRm.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent changeActivityToMain = new Intent(UpdateBtnActivity.this, MainActivity.class);
                changeActivityToMain.putExtra("dateSelected", dateSelected);
                changeActivityToMain.putExtra("cancel", true);
                startActivity(changeActivityToMain);
            }
        });

        btnConfirmRm.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if (selected.size() == 0) {
                    Intent changeActivityFinal = new Intent(UpdateBtnActivity.this, MainActivity.class);
                    startActivity(changeActivityFinal);
                } else {
                    ArrayList<Integer> datesIndex = new ArrayList<>();

                    for (int i = 0; i < dateEvents.size(); i++) {
                        if (dateEvents.get(i).equals(dateSelected)) {
                            datesIndex.add(i);
                        }
                    }
                    ArrayList<Integer> delIndex = new ArrayList<Integer>();
                    int[] ind;
                    for (int i = 0; i < datesIndex.size(); i++) {
                        for (int j = 0; j < selected.size(); j++) {
                            if (titleEvents.get(datesIndex.get(i)).equals(titleSelected.get(selected.get(j)))) {
                                if (timeEvents.get(datesIndex.get(i)).equals(timeSelected.get(selected.get(j)))) {
                                    delIndex.add(datesIndex.get(i));
                                }
                            }
                        }
                    }
                    ArrayList<String> newtitleEvents = new ArrayList<>();
                    ArrayList<String> newdescriptionEvents = new ArrayList<>();
                    ArrayList<String> newtimeEvents = new ArrayList<>();
                    ArrayList<String> newdateEvents = new ArrayList<>();
                    for (int i = 0; i < titleEvents.size(); i++) {
                        for (int j = 0; j < delIndex.size(); j++) {
                            if (i == delIndex.get(j)) {
                                uptitle = titleEvents.get(i);
                                updescription = descriptionEvents.get(i);
                                uptime = timeEvents.get(i);
                                update = dateEvents.get(i);
                            } else {
                                newtitleEvents.add(titleEvents.get(i));
                                newdescriptionEvents.add(descriptionEvents.get(i));
                                newtimeEvents.add(timeEvents.get(i));
                                newdateEvents.add(dateEvents.get(i));
                            }
                        }
                    }
                    Intent changeActivityFinal = new Intent(UpdateBtnActivity.this, AddActivity.class);
                    changeActivityFinal.putStringArrayListExtra("eventsTitle", newtitleEvents);
                    changeActivityFinal.putStringArrayListExtra("eventsDescription", newdescriptionEvents);
                    changeActivityFinal.putStringArrayListExtra("eventsTime", newtimeEvents);
                    changeActivityFinal.putStringArrayListExtra("eventsDate", newdateEvents);
                    changeActivityFinal.putExtra("titleForChange", uptitle);
                    changeActivityFinal.putExtra("descForChange", updescription);
                    changeActivityFinal.putExtra("timeForChange", uptime);
                    changeActivityFinal.putExtra("dateForChange", update);
                    changeActivityFinal.putExtra("FromUpdateBtn", true);
                    startActivity(changeActivityFinal);
                }


            }
        });


        listRemove.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                selected.clear();
                selected.add(position);
                /*if (selected.size() == 0) {
                    existItem = false;
                } else {
                    for (int i = 0; i < selected.size(); i++) {
                        if (selected.get(i).equals(nr)) {
                            selected.remove(i);
                            existItem = true;
                            break;
                        } else {
                            existItem = false;
                        }
                    }
                }

                if (!existItem) {
                    selected.add(nr);
                }*/

            }
        });


    }

    public void showEvents() {
        ArrayList<String> eventClick = new ArrayList<>();

        for (int i = 0; i < titleSelected.size(); i++) {
            String shortName = titleSelected.get(i) + " - " + timeSelected.get(i);
            eventClick.add(shortName);
        }

        ArrayAdapter<String> adapter = new ArrayAdapter<>(UpdateBtnActivity.this,
                android.R.layout.simple_list_item_single_choice, eventClick);

        listRemove.setAdapter(adapter);
    }
}
