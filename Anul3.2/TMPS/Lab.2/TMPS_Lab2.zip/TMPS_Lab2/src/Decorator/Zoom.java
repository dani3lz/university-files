package Decorator;

public interface Zoom {
    void zoom();
    String showReview();
}
