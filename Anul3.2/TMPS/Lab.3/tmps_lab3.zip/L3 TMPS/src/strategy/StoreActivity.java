package strategy;

public interface StoreActivity {
    void work();
    }