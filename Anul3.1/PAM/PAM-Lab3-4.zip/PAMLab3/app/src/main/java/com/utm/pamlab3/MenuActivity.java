package com.utm.pamlab3;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MenuActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);
        getSupportActionBar().hide();


        Button newsbtn = findViewById(R.id.newsbtn);
        Button psbtn = findViewById(R.id.psbtn);
        Button gamebtn = findViewById(R.id.gamebtn);
        Button checkbtn = findViewById(R.id.checkbtn);
        Button ps2btn = findViewById(R.id.ps2btn);
        Button catalogbtn = findViewById(R.id.catalogbtn);
        EditText urlText = findViewById(R.id.inputID);

        catalogbtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent changeActivity = new Intent(MenuActivity.this, CatalogActivity.class);
                startActivity(changeActivity);
            }
        });

        newsbtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent changeActivity = new Intent(MenuActivity.this, MainActivity.class);
                changeActivity.putExtra("url", "https://point.md/ru/rss/novosti");
                changeActivity.putExtra("FromMenu", true);
                startActivity(changeActivity);
            }
        });

        ps2btn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent changeActivity = new Intent(MenuActivity.this, MainActivity.class);
                changeActivity.putExtra("url", "https://pstationblog.ru/news/psn/feed/");
                changeActivity.putExtra("FromMenu", true);
                startActivity(changeActivity);
            }
        });

        psbtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent changeActivity = new Intent(MenuActivity.this, MainActivity.class);
                changeActivity.putExtra("url", "https://blog.ru.playstation.com/rss");
                changeActivity.putExtra("FromMenu", true);
                startActivity(changeActivity);
            }
        });

        gamebtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent changeActivity = new Intent(MenuActivity.this, MainActivity.class);
                changeActivity.putExtra("url", "https://freesteam.ru/feed/");
                changeActivity.putExtra("FromMenu", true);
                startActivity(changeActivity);
            }
        });

        checkbtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if (urlText.getText().toString().equals("")){
                    Toast.makeText(MenuActivity.this,"Insert a RSS feed URL", Toast.LENGTH_SHORT).show();
                }
                else {
                    Intent changeActivity = new Intent(MenuActivity.this, MainActivity.class);
                    changeActivity.putExtra("url", urlText.getText().toString());
                    changeActivity.putExtra("FromMenu", true);
                    startActivity(changeActivity);
                }
            }
        });
    }
}