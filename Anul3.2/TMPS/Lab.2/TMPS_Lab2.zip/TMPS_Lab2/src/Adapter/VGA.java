package Adapter;

public interface VGA {
    void usePortVGA();
    void show();
}
