package Facade.Interface;

public interface CPU {
    void startCPU(int MAX_TEMP_COOLING, boolean successfully);
    boolean stopCPU();
}
