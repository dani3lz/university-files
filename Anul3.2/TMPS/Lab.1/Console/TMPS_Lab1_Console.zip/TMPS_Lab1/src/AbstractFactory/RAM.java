package AbstractFactory;

public interface RAM extends AbstractComponents{

}
