package com.example.pam_lab2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.ArrayList;

public class UpdateActivity extends AppCompatActivity {
    ArrayList<String> eventsTitleUpdate = new ArrayList<>();
    ArrayList<String> eventsDescriptionUpdate = new ArrayList<>();
    ArrayList<String> eventsTimeUpdate = new ArrayList<>();
    ArrayList<String> eventsDatesUpdate = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update);
        getSupportActionBar().hide();
        Button btnBack = findViewById(R.id.btnBack);
        Button btnConfirm = findViewById(R.id.btnConfirm);
        TextView dateView = findViewById(R.id.dateViewU);
        TextView timeView = findViewById(R.id.timeView);
        TextView titleView = findViewById(R.id.titleView);
        TextView descriptionView = findViewById(R.id.descriptionView);

        String date = getIntent().getStringExtra("date");
        String time = getIntent().getStringExtra("time");
        String title = getIntent().getStringExtra("title");
        String description = getIntent().getStringExtra("description");

        eventsTitleUpdate = getIntent().getStringArrayListExtra("eventsTitle");
        eventsDescriptionUpdate = getIntent().getStringArrayListExtra("eventsDescription");
        eventsTimeUpdate = getIntent().getStringArrayListExtra("eventsTime");
        eventsDatesUpdate = getIntent().getStringArrayListExtra("eventsDate");

        dateView.setText(date);
        timeView.setText(time);
        titleView.setText(title);
        descriptionView.setText(description);

        btnBack.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent changeActivityToAdd = new Intent(UpdateActivity.this, AddActivity.class);
                changeActivityToAdd.putExtra("dateU", date);
                changeActivityToAdd.putExtra("timeU", time);
                changeActivityToAdd.putExtra("titleU", title);
                changeActivityToAdd.putExtra("descriptionU", description);
                changeActivityToAdd.putStringArrayListExtra("eventsTitle", eventsTitleUpdate);
                changeActivityToAdd.putStringArrayListExtra("eventsDescription", eventsDescriptionUpdate);
                changeActivityToAdd.putStringArrayListExtra("eventsTime", eventsTimeUpdate);
                changeActivityToAdd.putStringArrayListExtra("eventsDate", eventsDatesUpdate);
                changeActivityToAdd.putExtra("FromUpdate", true);
                startActivity(changeActivityToAdd);
            }
        });

        btnConfirm.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                String[] dateArray = date.split("/");

                int dateNr = Integer.parseInt(dateArray[0]);
                int monthNr = Integer.parseInt(dateArray[1]);
                int yearNr = Integer.parseInt(dateArray[2]);

                monthNr = monthNr - 1;

                String dateNew = dateNr+"/"+monthNr+"/"+yearNr;

                Intent changeActivityToMain = new Intent(UpdateActivity.this, MainActivity.class);
                changeActivityToMain.putExtra("dateU", dateNew);
                changeActivityToMain.putExtra("timeU", time);
                changeActivityToMain.putExtra("titleU", title);
                changeActivityToMain.putExtra("descriptionU", description);
                changeActivityToMain.putExtra("AddEvent", true);
                changeActivityToMain.putStringArrayListExtra("eventsTitle", eventsTitleUpdate);
                changeActivityToMain.putStringArrayListExtra("eventsDescription", eventsDescriptionUpdate);
                changeActivityToMain.putStringArrayListExtra("eventsTime", eventsTimeUpdate);
                changeActivityToMain.putStringArrayListExtra("eventsDate", eventsDatesUpdate);
                startActivity(changeActivityToMain);
            }
        });


    }
}