package template;

public class Model16 extends StoreTemplate {

    @Override
    public void showStoreContent() {
        System.out.println("Model: 16gb DDR4");
    }
}
