package template;

public class Model8 extends StoreTemplate {

    @Override
    public void showStoreContent() {
        System.out.println("Model: 8gb DDR4");
    }
}
