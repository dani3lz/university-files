package md.dani3lz.tmpslab1.AbstractFactory;

public interface GPU extends AbstractComponents{

}
