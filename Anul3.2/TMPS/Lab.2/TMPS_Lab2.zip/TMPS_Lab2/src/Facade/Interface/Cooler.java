package Facade.Interface;

public interface Cooler {
    boolean startCooler(int MAX_TEMP_COOLING);
    void stopCooler();
}
