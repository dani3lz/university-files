package Proxy;

public interface Product {
    void showProductFromJson();
}
