package Adapter;

public interface HDMI {
    void show();
    void usePortHDMI();
}
