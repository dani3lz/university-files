package com.example.pam_lab1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

public class SecondActivity extends AppCompatActivity {
    public ImageView imageee;
    private Button btn;
    public Bitmap photobit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        imageee = findViewById(R.id.imageVieww);
        btn = findViewById(R.id.button);

        byte[] byteArray = getIntent().getByteArrayExtra("image");
        photobit = BitmapFactory.decodeByteArray(byteArray, 0, byteArray.length);

        imageee.setImageBitmap(photobit);
        imageee.setRotation(90);


        // BACK
        btn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent changeActivity = new Intent(SecondActivity.this, MainActivity.class);
                startActivity(changeActivity);
            }
        });
    }

}