package strategy;

public class Sorting implements StoreActivity {
    @Override
    public void work() {
        System.out.println("Se sorteaza componentele pe rafturi...");
    }
}

