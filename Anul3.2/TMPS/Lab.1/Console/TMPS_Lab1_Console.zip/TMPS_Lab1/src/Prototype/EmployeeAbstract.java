package Prototype;

public abstract class EmployeeAbstract {
    public abstract EmployeeAbstract copy();
}
