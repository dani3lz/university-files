package com.example.pam_lab1;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.camera.core.CameraSelector;
import androidx.camera.core.ImageCapture;
import androidx.camera.core.ImageCaptureException;
import androidx.camera.core.Preview;
import androidx.camera.lifecycle.ProcessCameraProvider;
import androidx.camera.view.PreviewView;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.core.content.ContextCompat;
import androidx.lifecycle.LifecycleOwner;

import android.app.PendingIntent;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Environment;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Toast;

import com.google.common.util.concurrent.ListenableFuture;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.util.Date;
import java.util.concurrent.Executor;

public class MainActivity extends AppCompatActivity {
    private ListenableFuture<ProcessCameraProvider> cameraProviderFuture;
    PreviewView previewView;
    private ImageCapture imageCapture;
    private RadioButton radioBack, radioFront;
    private EditText textbox;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        previewView = findViewById(R.id.previewView);
        previewView.setRotation(180);
        radioBack = findViewById(R.id.radioBack);
        radioBack.setChecked(true);
        radioFront = findViewById(R.id.radioFront);
        textbox = findViewById(R.id.textbox);



        cameraProviderFuture = ProcessCameraProvider.getInstance(MainActivity.this);
        cameraProviderFuture.addListener(()-> {
            try {
                ProcessCameraProvider cameraProvider = cameraProviderFuture.get();
                startCameraX(cameraProvider, 0);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }, getExecutor());

        // Notification
        final Button button = findViewById(R.id.btn1);
        button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {

                Intent resultIntent = new Intent(MainActivity.this, MainActivity.class);
                PendingIntent resultPendingIntent = PendingIntent.getActivity(MainActivity.this, 1, resultIntent, PendingIntent.FLAG_UPDATE_CURRENT);


                NotificationCompat.Builder mBuilder = new NotificationCompat.Builder(MainActivity.this, "My notification")
                        .setSmallIcon(R.drawable.ic_launcher_background)
                        .setContentTitle("PAM Lab.1")
                        .setContentText("Click pentru a deschide aplicatia.")
                        .setAutoCancel(true)
                        .setContentIntent(resultPendingIntent)
                        .setPriority(NotificationCompat.PRIORITY_MAX);

                Toast.makeText(MainActivity.this, "Notificarea va aparea peste 10 secunde.", Toast.LENGTH_SHORT).show();
                    new CountDownTimer(10000, 1000){
                        public void onTick(long millisUntilFinished){

                        }
                        public  void onFinish(){
                            NotificationManagerCompat mng = NotificationManagerCompat.from(MainActivity.this);
                            mng.notify(1, mBuilder.build());
                        }
                    }.start();
            }
        });



        // Browser
        final Button button3 = findViewById(R.id.btn3);
        button3.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                String key = textbox.getText().toString();
                if (key.equals("")) {
                    Toast.makeText(MainActivity.this, "Introduceti cuvantul cheie.", Toast.LENGTH_SHORT).show();
                }
                else {
                    Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + key));
                    startActivity(browserIntent);
                    textbox.setText("");
                }
            }
        });

        // Toggle
        final Button button2 = findViewById(R.id.btn2);
        button2.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if(radioBack.isChecked()){
                    cameraProviderFuture.addListener(()-> {
                        try {
                            ProcessCameraProvider cameraProvider = cameraProviderFuture.get();
                            startCameraX(cameraProvider, 0);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }, getExecutor());

                }
                else {
                    if(radioFront.isChecked()) {
                        cameraProviderFuture.addListener(()-> {
                            try {
                                ProcessCameraProvider cameraProvider = cameraProviderFuture.get();
                                startCameraX(cameraProvider, 1);
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }, getExecutor());
                    }
                }


            }

        });

        // Photo
        final Button button4 = findViewById(R.id.btn4);
        button4.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                capturePhoto();
            }
        });
    }

    private Executor getExecutor(){
        return ContextCompat.getMainExecutor(MainActivity.this);
    }

    private void startCameraX(ProcessCameraProvider cameraProvider, int id){
        cameraProvider.unbindAll();
        if(id == 0) {
            CameraSelector cameraSelector = new CameraSelector.Builder()
                    .requireLensFacing(CameraSelector.LENS_FACING_BACK)
                    .build();



            Preview preview = new Preview.Builder().build();
            preview.setSurfaceProvider(previewView.getSurfaceProvider());

            imageCapture = new ImageCapture.Builder()
                    .setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY)
                    .build();

            cameraProvider.bindToLifecycle((LifecycleOwner) this, cameraSelector, preview, imageCapture);
        }
        else{
            CameraSelector cameraSelector = new CameraSelector.Builder()
                    .requireLensFacing(CameraSelector.LENS_FACING_FRONT)
                    .build();

            Preview preview = new Preview.Builder().build();
            preview.setSurfaceProvider(previewView.getSurfaceProvider());

            imageCapture = new ImageCapture.Builder()
                    .setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY)
                    .build();

            cameraProvider.bindToLifecycle((LifecycleOwner) this, cameraSelector, preview, imageCapture);
        }

    }

    public void capturePhoto(){
        File photodir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES) + "/PAMLab");
        if(!photodir.exists()) {
            photodir.mkdir();
        }

        Date date = new Date();
        String timestamp = String.valueOf(date.getTime());
        String photoFilePath = photodir.getAbsolutePath() + "/" + timestamp + ".jpg";

        File photoFile = new File(photoFilePath);

        imageCapture.takePicture(
                new ImageCapture.OutputFileOptions.Builder(photoFile).build(),
                getExecutor(),
                new ImageCapture.OnImageSavedCallback() {
                    @Override
                    public void onImageSaved(@NonNull ImageCapture.OutputFileResults outputFileResults){
                        Toast.makeText(MainActivity.this, "Poza a fost efectuata cu succes.", Toast.LENGTH_SHORT).show();

                        Bitmap bmp = BitmapFactory.decodeFile(photoFilePath);

                        ByteArrayOutputStream stream = new ByteArrayOutputStream();
                        bmp.compress(Bitmap.CompressFormat.JPEG, 100, stream);
                        byte[] byteArray = stream.toByteArray();

                        Intent changeActivity = new Intent(MainActivity.this, SecondActivity.class);
                        changeActivity.putExtra("image", byteArray);
                        startActivity(changeActivity);
                    }

                    @Override
                    public void onError(@NonNull ImageCaptureException exception){
                        Toast.makeText(MainActivity.this, "Error: " + exception.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }

        );

    }

}
