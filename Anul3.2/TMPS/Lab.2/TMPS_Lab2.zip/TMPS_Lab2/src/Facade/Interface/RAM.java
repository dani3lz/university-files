package Facade.Interface;

public interface RAM {
    void startRAM();
    void stopRAM();
}
