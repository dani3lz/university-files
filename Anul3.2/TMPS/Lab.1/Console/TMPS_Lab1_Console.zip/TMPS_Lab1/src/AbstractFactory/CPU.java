package AbstractFactory;

public interface CPU extends AbstractComponents {

}
