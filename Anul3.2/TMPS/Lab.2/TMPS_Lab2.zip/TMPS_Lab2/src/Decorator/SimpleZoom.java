package Decorator;

public class SimpleZoom implements Zoom {
    @Override
    public void zoom() {

    }

    @Override
    public String showReview() {
        return "show short review";
    }
}
