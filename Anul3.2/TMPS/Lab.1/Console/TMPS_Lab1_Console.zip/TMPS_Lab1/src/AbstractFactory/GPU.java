package AbstractFactory;

public interface GPU extends AbstractComponents{

}
