package com.utm.pamlab3;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlPullParserFactory;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;

public class CatalogActivity extends AppCompatActivity {
    ListView mylist;
    ArrayList<String> titles = new ArrayList<String>();
    ArrayList<String> links = new ArrayList<String>();
    ArrayList<String> titlesXML;
    ArrayList<String> linksXML;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_catalog);
        getSupportActionBar().hide();

        mylist = findViewById(R.id.listCatalogID);
        Button backCatalog = findViewById(R.id.backCatelogbtn);
        mylist.setChoiceMode(ListView.CHOICE_MODE_SINGLE);
        Button delbtn = findViewById(R.id.delbtn);

        titlesXML = new ArrayList<String>();
        linksXML = new ArrayList<String>();

        // Read XML
        readFromXml();

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(CatalogActivity.this, android.R.layout.simple_expandable_list_item_1, titlesXML);
        mylist.setAdapter(adapter);

        mylist.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Uri uri = Uri.parse(linksXML.get(position));
                Intent intent = new Intent(Intent.ACTION_VIEW, uri);
                startActivity(intent);
            }
        });

        backCatalog.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent changeActivity = new Intent(CatalogActivity.this, MenuActivity.class);
                startActivity(changeActivity);
            }
        });

        delbtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent changeActivity = new Intent(CatalogActivity.this, SaveActivity.class);
                changeActivity.putStringArrayListExtra("titles", titlesXML);
                changeActivity.putStringArrayListExtra("links", linksXML);
                changeActivity.putStringArrayListExtra("titlesXML", titlesXML);
                changeActivity.putStringArrayListExtra("linksXML", linksXML);
                changeActivity.putExtra("FromCatalog", true);
                changeActivity.putExtra("url", "urlCheck");
                startActivity(changeActivity);
            }
        });



    }

    // ---------------------------------------------------------------------------------------------

    public void readFromXml(){
        XmlPullParserFactory parserFactory;
        try {
            FileInputStream is = new FileInputStream(getFilesDir() + "/rssItems.xml");
            parserFactory = XmlPullParserFactory.newInstance();
            XmlPullParser parser = parserFactory.newPullParser();
            parser.setFeature(XmlPullParser.FEATURE_PROCESS_NAMESPACES, false);
            parser.setInput(is, null);
            processParsing(parser);

        } catch (XmlPullParserException e) {

        } catch (IOException e) {
        }
    }

    private void processParsing(XmlPullParser parser) throws IOException, XmlPullParserException{
        int eventType = parser.getEventType();

        while (eventType != XmlPullParser.END_DOCUMENT) {
            String eltName = null;
            switch (eventType) {
                case XmlPullParser.START_TAG:
                    eltName = parser.getName();

                    if ("item".equals(eltName)) {

                    } else if (true) {
                        if ("title".equals(eltName)) {
                            titlesXML.add(parser.nextText());

                        } else if ("link".equals(eltName)) {
                            linksXML.add(parser.nextText());
                        }
                    }
                    break;
            }

            eventType = parser.next();
        }
    }
}