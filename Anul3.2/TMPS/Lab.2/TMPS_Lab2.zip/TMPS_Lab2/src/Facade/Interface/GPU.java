package Facade.Interface;

public interface GPU {
    void startGPU();
    void stopGPU();
}
