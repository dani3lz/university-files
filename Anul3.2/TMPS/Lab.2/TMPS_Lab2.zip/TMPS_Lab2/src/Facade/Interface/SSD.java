package Facade.Interface;

public interface SSD {
    void startSSD();
    void stopSSD();
}
