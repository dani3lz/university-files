package com.example.pam_lab2;

import androidx.appcompat.app.AppCompatActivity;


import android.app.AlarmManager;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.text.format.DateFormat;
import android.util.Xml;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlPullParserFactory;
import org.xmlpull.v1.XmlSerializer;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.StringWriter;
import java.sql.Date;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;


public class MainActivity extends AppCompatActivity {
    ArrayList<String> eventsTitle = new ArrayList<>();
    ArrayList<String> eventsDescription = new ArrayList<>();
    ArrayList<String> eventsTime = new ArrayList<>();
    ArrayList<String> eventsDates = new ArrayList<>();
    EditText keyword;
    CalendarView calendar;
    ListView eventList;
    String dateSelected;
    boolean removeEvent = false;
    boolean fromUpdate = false;
    boolean fromSearch = false;
    boolean cancelbtn = false;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportActionBar().hide();
        Button btnAdd = findViewById(R.id.btnAdd);
        Button btnRemove = findViewById(R.id.btnRemove);
        Button btnUpdate = findViewById(R.id.btnUpdate);
        Button btnSearch = findViewById(R.id.btnSearch);
        calendar = findViewById(R.id.calendarView);
        keyword = findViewById(R.id.textSearch);
        eventList = findViewById(R.id.listView);
        dateSelected = convertToDate(calendar.getDate());

        fromUpdate = getIntent().getBooleanExtra("AddEvent", false);
        removeEvent = getIntent().getBooleanExtra("RemoveEvent", false);
        fromSearch = getIntent().getBooleanExtra("FromSearch", false);
        cancelbtn = getIntent().getBooleanExtra("cancel", false);

        // Init
        readFromXml();

        // Show events
        Calendar calendarInit = Calendar.getInstance();
        final int year = calendarInit.get(Calendar.YEAR);
        final int month = calendarInit.get(Calendar.MONTH);
        final int day = calendarInit.get(Calendar.DAY_OF_MONTH);
        showEvents(year,month,day);

        if(cancelbtn){
            dateSelected = getIntent().getStringExtra("dateSelected");
            String[] dateArray = dateSelected.split("/");

            int dayNr = Integer.parseInt(dateArray[0]);
            int monthNr = Integer.parseInt(dateArray[1]);
            int yearNr = Integer.parseInt(dateArray[2]);

            GregorianCalendar gc = new GregorianCalendar(yearNr,monthNr,dayNr);
            long timeStamp = gc.getTimeInMillis();
            calendar.setDate(timeStamp);
            showEvents(yearNr,monthNr,dayNr);

        }

        if(fromSearch){
            eventsTitle = getIntent().getStringArrayListExtra("eventsTitle");
            eventsDescription = getIntent().getStringArrayListExtra("eventsDescription");
            eventsTime = getIntent().getStringArrayListExtra("eventsTime");
            eventsDates = getIntent().getStringArrayListExtra("eventsDate");
            dateSelected = getIntent().getStringExtra("dateSelected");
            String[] dateArray = dateSelected.split("/");

            int dayNr = Integer.parseInt(dateArray[0]);
            int monthNr = Integer.parseInt(dateArray[1]);
            int yearNr = Integer.parseInt(dateArray[2]);
            GregorianCalendar gc = new GregorianCalendar(yearNr,monthNr,dayNr);
            long timeStamp = gc.getTimeInMillis();
            showEvents(yearNr,monthNr,dayNr);
            calendar.setDate(timeStamp);
        }

        if(removeEvent){
            eventsTitle = getIntent().getStringArrayListExtra("eventsTitle");
            eventsDescription = getIntent().getStringArrayListExtra("eventsDescription");
            eventsTime = getIntent().getStringArrayListExtra("eventsTime");
            eventsDates = getIntent().getStringArrayListExtra("eventsDate");
            dateSelected = getIntent().getStringExtra("dateSelected");
            writeToXml();

            String[] dateArray = dateSelected.split("/");

            int dayNr = Integer.parseInt(dateArray[0]);
            int monthNr = Integer.parseInt(dateArray[1]);
            int yearNr = Integer.parseInt(dateArray[2]);
            GregorianCalendar gc = new GregorianCalendar(yearNr,monthNr,dayNr);
            long timeStamp = gc.getTimeInMillis();
            showEvents(yearNr,monthNr,dayNr);
            calendar.setDate(timeStamp);
        }

        if (fromUpdate) {
            String date = getIntent().getStringExtra("dateU");
            String time = getIntent().getStringExtra("timeU");
            String title = getIntent().getStringExtra("titleU");
            String description = getIntent().getStringExtra("descriptionU");

            eventsTitle = getIntent().getStringArrayListExtra("eventsTitle");
            eventsDescription = getIntent().getStringArrayListExtra("eventsDescription");
            eventsTime = getIntent().getStringArrayListExtra("eventsTime");
            eventsDates = getIntent().getStringArrayListExtra("eventsDate");

            addEventToCalendar(date, time, title, description);
        }



        // Add
        btnAdd.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent changeActivity = new Intent(MainActivity.this, AddActivity.class);
                changeActivity.putStringArrayListExtra("eventsTitle", eventsTitle);
                changeActivity.putStringArrayListExtra("eventsDescription", eventsDescription);
                changeActivity.putStringArrayListExtra("eventsTime", eventsTime);
                changeActivity.putStringArrayListExtra("eventsDate", eventsDates);
                changeActivity.putExtra("FromMain", true);
                startActivity(changeActivity);
            }
        });

        // Remove
        btnRemove.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {

                if(dateSelected.equals("")){
                    Toast.makeText(MainActivity.this, "Select a date", Toast.LENGTH_SHORT).show();
                }
                else {
                    ArrayList<String> titleSelected = new ArrayList<>();
                    ArrayList<String> timeSelected = new ArrayList<>();
                    selectedEvents(dateSelected, titleSelected, timeSelected);

                    Intent changeActivityRemove = new Intent(MainActivity.this, RemoveActivity.class);
                    changeActivityRemove.putStringArrayListExtra("titleSelected", titleSelected);
                    changeActivityRemove.putStringArrayListExtra("timeSelected", timeSelected);
                    changeActivityRemove.putStringArrayListExtra("eventsTitle", eventsTitle);
                    changeActivityRemove.putStringArrayListExtra("eventsDescription", eventsDescription);
                    changeActivityRemove.putStringArrayListExtra("eventsTime", eventsTime);
                    changeActivityRemove.putStringArrayListExtra("eventsDate", eventsDates);
                    changeActivityRemove.putExtra("dateSelected", dateSelected);
                    startActivity(changeActivityRemove);
                }
            }
        });

        // Update
        btnUpdate.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if(dateSelected.equals("")){
                    Toast.makeText(MainActivity.this, "Select a date", Toast.LENGTH_SHORT).show();
                }
                else {
                    ArrayList<String> titleSelected = new ArrayList<>();
                    ArrayList<String> timeSelected = new ArrayList<>();
                    selectedEvents(dateSelected, titleSelected, timeSelected);

                    Intent changeActivityRemove = new Intent(MainActivity.this, UpdateBtnActivity.class);
                    changeActivityRemove.putStringArrayListExtra("titleSelected", titleSelected);
                    changeActivityRemove.putStringArrayListExtra("timeSelected", timeSelected);
                    changeActivityRemove.putStringArrayListExtra("eventsTitle", eventsTitle);
                    changeActivityRemove.putStringArrayListExtra("eventsDescription", eventsDescription);
                    changeActivityRemove.putStringArrayListExtra("eventsTime", eventsTime);
                    changeActivityRemove.putStringArrayListExtra("eventsDate", eventsDates);
                    changeActivityRemove.putExtra("dateSelected", dateSelected);
                    startActivity(changeActivityRemove);
                }


            }
        });

        // Search
        btnSearch.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                String key = keyword.getText().toString();
                if(key.equals("")){
                    Toast.makeText(MainActivity.this, "The keyword is not entered", Toast.LENGTH_SHORT).show();
                }
                else {
                    String input = key;
                    input = input.toUpperCase();
                    ArrayList<String> titlesSearch = new ArrayList<>();
                    ArrayList<String> timeSearch = new ArrayList<>();
                    ArrayList<String> dateSearch = new ArrayList<>();
                    ArrayList<Integer> titleIndex = new ArrayList<>();
                    for(int i = 0; i < eventsTitle.size(); i++){
                        String titleCh = eventsTitle.get(i);
                        titleCh = titleCh.toUpperCase();
                        if(titleCh.indexOf(input) == 0){
                            titlesSearch.add(eventsTitle.get(i));
                            timeSearch.add(eventsTime.get(i));
                            dateSearch.add(eventsDates.get(i));
                            titleIndex.add(i);
                        }
                    }
                    if(titlesSearch.size() != 0){
                        Intent changeActivitySearch = new Intent(MainActivity.this, SearchActivity.class);
                        changeActivitySearch.putStringArrayListExtra("eventsTitle", eventsTitle);
                        changeActivitySearch.putStringArrayListExtra("eventsDescription", eventsDescription);
                        changeActivitySearch.putStringArrayListExtra("eventsTime", eventsTime);
                        changeActivitySearch.putStringArrayListExtra("eventsDate", eventsDates);
                        changeActivitySearch.putStringArrayListExtra("titlesSearch", titlesSearch);
                        changeActivitySearch.putStringArrayListExtra("timeSearch", timeSearch);
                        changeActivitySearch.putStringArrayListExtra("dateSearch", dateSearch);
                        changeActivitySearch.putIntegerArrayListExtra("titleIndex", titleIndex);
                        startActivity(changeActivitySearch);
                    }
                    else {
                        Toast.makeText(MainActivity.this, "Nothing was found", Toast.LENGTH_SHORT).show();
                    }

                }

            }
        });

        calendar.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
            @Override
            public void onSelectedDayChange(CalendarView view, int year, int month,
                                            int dayOfMonth) {
                dateSelected = dayOfMonth+"/"+month+"/"+year;
               showEvents(year,month,dayOfMonth);
            }
        });

    }
    public void createNotificationChannell(String timee, long datee, String title, String description){
        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.O){
            CharSequence name = title;
            String desc = description;
            int importance = NotificationManager.IMPORTANCE_DEFAULT;
            NotificationChannel channel = new NotificationChannel("notifyEvents", name, importance);
            channel.setDescription(desc);

            NotificationManager notifyM = getSystemService(NotificationManager.class);
            notifyM.createNotificationChannel(channel);
        }
        Intent intentToAlarm = new Intent(MainActivity.this, ReminderBroadcast.class);
        intentToAlarm.putExtra("title", title);
        intentToAlarm.putExtra("desc", description);
        PendingIntent pendingIntent = PendingIntent.getBroadcast(MainActivity.this,0,intentToAlarm,0);

        AlarmManager alarmManager = (AlarmManager) getSystemService(ALARM_SERVICE);

        String[] dateArray = timee.split(":");

        int hour = Integer.parseInt(dateArray[0]);
        int min = Integer.parseInt(dateArray[1]);
        long hourstamp = hour * 60 * 60 * 1000;
        long minstamp = min * 60 * 1000;
        long hmd = hourstamp + minstamp + datee;

        alarmManager.set(AlarmManager.RTC_WAKEUP,hmd, pendingIntent);
    }

    public void selectedEvents(String dateClick, ArrayList<String> titleSelected, ArrayList<String> timeSelected){
        ArrayList<Integer> datesIndex = new ArrayList<>();

        for(int i = 0; i < eventsDates.size(); i++){
            if(eventsDates.get(i).equals(dateClick)){
                datesIndex.add(i);
            }
        }

        for(int i = 0; i < datesIndex.size(); i++){
            int nr = datesIndex.get(i);
            titleSelected.add(eventsTitle.get(nr));
            timeSelected.add(eventsTime.get(nr));
        }
    }

    public void addEventToCalendar(String date, String time, String title, String description){

        eventsTitle.add(title);
        eventsDescription.add(description);
        eventsTime.add(time);
        eventsDates.add(date);

        String[] dateArray = date.split("/");

        int dayNr = Integer.parseInt(dateArray[0]);
        int monthNr = Integer.parseInt(dateArray[1]);
        int yearNr = Integer.parseInt(dateArray[2]);

        GregorianCalendar gc = new GregorianCalendar(yearNr,monthNr,dayNr);
        long timeStamp = gc.getTimeInMillis();
        createNotificationChannell(time, timeStamp, title, description);

        Toast.makeText(MainActivity.this, "The event was saved successfully", Toast.LENGTH_SHORT).show();
        calendar.setDate(timeStamp);
        dateSelected = convertToDate(timeStamp);
        writeToXml();
        showEvents(yearNr,monthNr,dayNr);
    }

    public String convertToDate(long timestamp){
        long millisecond = Long.parseLong(String.valueOf(timestamp));
        String date = DateFormat.format("dd/MM/yyyy", new Date(millisecond)).toString();
        String[] dateArray = date.split("/");

        int dayNr = Integer.parseInt(dateArray[0]);
        int monthNr = Integer.parseInt(dateArray[1]) - 1;
        int yearNr = Integer.parseInt(dateArray[2]);
        return dayNr+"/"+monthNr+"/"+yearNr;

    }


    public void showEvents(int year, int month, int dayOfMonth){
        String dateClick =dayOfMonth+"/"+month+"/"+year;

        ArrayList<Integer> datesIndex = new ArrayList<>();

        for(int i = 0; i < eventsDates.size(); i++){
            if(eventsDates.get(i).equals(dateClick)){
                datesIndex.add(i);
            }
        }

        ArrayList<String> eventClick = new ArrayList<>();

        for(int i = 0; i < datesIndex.size(); i++){
            int nr = datesIndex.get(i);
            String shortName = eventsTitle.get(nr) + " - " + eventsTime.get(nr);
            eventClick.add(shortName);
        }
        // ----------------------------

        ArrayAdapter<String> adapter = new ArrayAdapter<>(MainActivity.this,
                android.R.layout.simple_list_item_1, eventClick);

        eventList.setAdapter(adapter);
    }


    // ---------------------------------------------------------------------------------------------

    public void readFromXml(){
        XmlPullParserFactory parserFactory;
        try {
            FileInputStream is = new FileInputStream(getFilesDir() + "/events.xml");
            parserFactory = XmlPullParserFactory.newInstance();
            XmlPullParser parser = parserFactory.newPullParser();
            parser.setFeature(XmlPullParser.FEATURE_PROCESS_NAMESPACES, false);
            parser.setInput(is, null);
            processParsing(parser);

        } catch (XmlPullParserException e) {

        } catch (IOException e) {
        }
    }

    private void processParsing(XmlPullParser parser) throws IOException, XmlPullParserException{
        int eventType = parser.getEventType();

        while (eventType != XmlPullParser.END_DOCUMENT) {
            String eltName = null;
            switch (eventType) {
                case XmlPullParser.START_TAG:
                    eltName = parser.getName();

                    if ("Event".equals(eltName)) {

                    } else if (true) {
                        if ("Title".equals(eltName)) {
                            eventsTitle.add(parser.nextText());

                        } else if ("Description".equals(eltName)) {
                            eventsDescription.add(parser.nextText());
                        } else if ("Time".equals(eltName)) {
                            eventsTime.add(parser.nextText());
                        } else if ("Date".equals(eltName)) {
                            eventsDates.add(parser.nextText());
                        }
                    }
                    break;
            }

            eventType = parser.next();
        }
    }

// -------------------------------------------------------------------------------------------------

    public void writeToXml(){
        try {
            FileOutputStream fileos = new FileOutputStream(getFilesDir() + "/events.xml");
            XmlSerializer xmlSerializer = Xml.newSerializer();
            StringWriter writer = new StringWriter();
            xmlSerializer.setOutput(writer);

            xmlSerializer.startDocument("UTF-8", true);
            xmlSerializer.setFeature("http://xmlpull.org/v1/doc/features.html#indent-output", true);

            xmlSerializer.startTag("", "Events");
            for (int i = 0; i < eventsDates.size(); i++) {

                xmlSerializer.startTag("", "Event");

                xmlSerializer.startTag("", "Title");
                xmlSerializer.text(eventsTitle.get(i));
                xmlSerializer.endTag("", "Title");

                xmlSerializer.startTag("", "Description");
                xmlSerializer.text(eventsDescription.get(i));
                xmlSerializer.endTag("", "Description");

                xmlSerializer.startTag("", "Time");
                xmlSerializer.text(eventsTime.get(i));
                xmlSerializer.endTag("", "Time");

                xmlSerializer.startTag("", "Date");
                xmlSerializer.text(eventsDates.get(i));
                xmlSerializer.endTag("", "Date");

                xmlSerializer.endTag("", "Event");
            }

            xmlSerializer.endTag("", "Events");

            xmlSerializer.endDocument();
            xmlSerializer.flush();

            String dataWrite = writer.toString();

            fileos.write(dataWrite.getBytes());
            fileos.close();
        }
        catch (FileNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        catch (IllegalArgumentException e) {
            // TODO Auto-generated catch block

            e.printStackTrace();
        }
        catch (IllegalStateException e) {
            // TODO Auto-generated catch block

            e.printStackTrace();
        }
        catch (IOException e) {
            // TODO Auto-generated catch block

            e.printStackTrace();
        }
    }



}
