package Iterator;

public interface Collection {
    Iterator getIterator();
}
