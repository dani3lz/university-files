package Facade.Interface;

public interface PowerSupply {
    boolean startPower(int MAX_POWER);
    boolean stopPower();
}
