package state;

public class Sorting implements StoreActivity {
    @Override
    public void work() {
        System.out.println("Se sorteaza componentele...");
    }
}
