package state;

public interface StoreActivity {
    void work();
}
